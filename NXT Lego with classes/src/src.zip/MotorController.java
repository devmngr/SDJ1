public class MotorController
{
   private int power;
   private double distance;
   private double degrees;
   private double wheelDiameter = 5.6;
   private double wheelRadius;
   private double wheelCircumference;
   private double distBetween = 16.5;
   private double tachoDistance;
   
   public void setPower(int power)
   {
      this.power=power;
   }
   public int getPower()
   {
      return power;
   }
   public void setDistance(double distance)
   {
      this.distance=distance;
   }
   public double getDistance()
   {
      return distance;
   }
   public void setWheelDiameter(double wheelDiameter)
   {
      this.wheelDiameter=wheelDiameter;
   }
   public double getWheelDiameter()
   {
      return wheelDiameter;
   }
   public void setWheelRadius(double wheelRadius)
   {
      this.wheelRadius= wheelRadius;
   }
   public double getWheelRadius()
   {
      return getWheelDiameter()/2;
   }
   public void setWheelCircumference(double wheelCircumference)
   {
      this.wheelCircumference=wheelCircumference;
   }
   public double getWheelCircumference()
   {
      return 2*Math.PI * getWheelRadius();
   }
   public void setDistanceBetween(double distBetween)
   {
      this.distBetween=distBetween;
   }
   public double getDistanceBetween()
   {
      return distBetween;
   }
   public void setDegrees(double degrees)
   {
      this.degrees=degrees;
   }
   public double getDegrees()
   {
      return degrees;
   }
   public double getTurnDistance()
   {
      if (degrees>0 && degrees<360)
      {
         return (2*Math.PI * getDistanceBetween())/(360/getDegrees());
      }
      else if (degrees>=360)
      {
         return (2*Math.PI * getDistanceBetween())*(getDegrees()/360);
      }
      else
         return 0;
   }
   public void setTachoDistance()
   {
      this.tachoDistance=tachoDistance;
   }
   public double getTachoDistance()
   {
      return (getDistance() / getWheelCircumference()) * 360;
   }
   public double getTachoFwd()
   {
    return ((getDistance() /getWheelCircumference())*360)/2;  
   }
   public double getTachoBack()
   {
      return getTachoFwd() / 2;
   }
   
   

   
   
   
 
   

}
