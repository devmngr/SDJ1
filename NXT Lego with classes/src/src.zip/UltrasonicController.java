
public class UltrasonicController
{
   
   private double distance;


   public void setDistance(double distance)
   {
      this.distance = distance;
   }
   
   
   public double getDist()
   {
      return distance;
   }
   
   
   public String toString()
   {
      return "Distance: " + distance;
   }

}
